package com.example.aksalfirmansyah_uas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Biodata extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biodata);
    }
}